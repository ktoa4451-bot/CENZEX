# CENZEX — source starter

A clean, original Fabric client-side UI/HUD framework for Minecraft 1.21.11 and Java 21.

## Included
- Right Shift opens the ClickGUI
- Categories: Combat, Visual, Misc, Skins
- Example local modules and click-to-toggle controls
- Properties-based configuration saved to `config/cenzex.properties`
- Fabric client entrypoint and Gradle source project

## Important
This is a new, independent starter implementation. It does **not** contain copied Celestial, Expensive, or Zenith code, and it does not implement anti-cheat bypasses or multiplayer combat cheats. Only integrate third-party source where you have permission and the applicable license allows it.

## Build
Use JDK 21 and Gradle. Open this folder as a Gradle project, then run `gradle build` (or add a Gradle wrapper using a trusted Gradle installation). Dependency versions in `gradle.properties` may need adjustment to the exact Fabric Maven releases available in your environment.
