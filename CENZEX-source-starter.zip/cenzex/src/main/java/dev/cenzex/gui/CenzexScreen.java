package dev.cenzex.gui;

import dev.cenzex.config.ConfigManager;
import dev.cenzex.module.ClientModule;
import dev.cenzex.module.ModuleRegistry;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public final class CenzexScreen extends Screen {
    private static final String[] CATEGORIES = {"Combat", "Visual", "Misc", "Skins"};
    private String selected = "Visual";
    private int panelX, panelY, panelW = 390, panelH = 270;

    public CenzexScreen() { super(Text.literal("CENZEX")); }

    @Override
    protected void init() {
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF20D0A18);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + 3, 0xFF9B5CFF);
        ctx.drawText(textRenderer, "CENZEX", panelX + 16, panelY + 13, 0xFFE5D5FF, false);
        ctx.drawText(textRenderer, "FABRIC 1.21.11  •  CLIENT UI", panelX + 16, panelY + 28, 0xFF9B8BAF, false);

        int cy = panelY + 52;
        for (String category : CATEGORIES) {
            boolean active = category.equals(selected);
            int color = active ? 0xFF5B347F : 0xFF21182D;
            ctx.fill(panelX + 12, cy, panelX + 104, cy + 22, color);
            ctx.drawText(textRenderer, category, panelX + 20, cy + 7, active ? 0xFFFFFFFF : 0xFFBDB0CE, false);
            cy += 27;
        }
        ctx.drawText(textRenderer, selected.toUpperCase(), panelX + 122, panelY + 53, 0xFFDCCBFF, false);
        List<ClientModule> modules = ModuleRegistry.inCategory(selected);
        int rowY = panelY + 76;
        for (ClientModule module : modules) {
            ctx.fill(panelX + 118, rowY, panelX + panelW - 12, rowY + 35, 0xFF1B1525);
            ctx.drawText(textRenderer, module.name(), panelX + 128, rowY + 7, 0xFFF3EDFF, false);
            ctx.drawText(textRenderer, module.enabled() ? "ON" : "OFF", panelX + panelW - 49, rowY + 7,
                    module.enabled() ? 0xFFBDA0FF : 0xFF8D829B, false);
            ctx.drawText(textRenderer, module.description(), panelX + 128, rowY + 20, 0xFF9F94AE, false);
            rowY += 40;
        }
        ctx.drawText(textRenderer, "Right Shift: open/close  •  Click modules to toggle", panelX + 12, panelY + panelH - 17, 0xFF8D829B, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int cy = panelY + 52;
        for (String category : CATEGORIES) {
            if (mouseX >= panelX + 12 && mouseX <= panelX + 104 && mouseY >= cy && mouseY <= cy + 22) {
                selected = category; return true;
            }
            cy += 27;
        }
        int rowY = panelY + 76;
        for (ClientModule module : ModuleRegistry.inCategory(selected)) {
            if (mouseX >= panelX + 118 && mouseX <= panelX + panelW - 12 && mouseY >= rowY && mouseY <= rowY + 35) {
                module.toggle(); ConfigManager.save(); return true;
            }
            rowY += 40;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { ConfigManager.save(); super.close(); }
}
