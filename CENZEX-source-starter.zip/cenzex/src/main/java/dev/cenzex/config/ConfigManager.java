package dev.cenzex.config;

import dev.cenzex.module.ClientModule;
import dev.cenzex.module.ModuleRegistry;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class ConfigManager {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("cenzex.properties");
    private ConfigManager() {}
    public static void load() {
        if (!Files.exists(FILE)) return;
        Properties p = new Properties();
        try (var in = Files.newInputStream(FILE)) {
            p.load(in);
            for (ClientModule m : ModuleRegistry.all()) m.setEnabled(Boolean.parseBoolean(p.getProperty("module." + m.name(), "false")));
        } catch (IOException e) { System.err.println("[CENZEX] Could not load config: " + e.getMessage()); }
    }
    public static void save() {
        Properties p = new Properties();
        for (ClientModule m : ModuleRegistry.all()) p.setProperty("module." + m.name(), Boolean.toString(m.enabled()));
        try {
            Files.createDirectories(FILE.getParent());
            try (var out = Files.newOutputStream(FILE)) { p.store(out, "CENZEX client settings"); }
        } catch (IOException e) { System.err.println("[CENZEX] Could not save config: " + e.getMessage()); }
    }
}
