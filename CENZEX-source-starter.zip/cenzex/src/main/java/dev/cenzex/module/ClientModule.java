package dev.cenzex.module;

public final class ClientModule {
    private final String name;
    private final String category;
    private final String description;
    private boolean enabled;

    public ClientModule(String name, String category, String description) {
        this.name = name; this.category = category; this.description = description;
    }
    public String name() { return name; }
    public String category() { return category; }
    public String description() { return description; }
    public boolean enabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public void toggle() { enabled = !enabled; }
}
