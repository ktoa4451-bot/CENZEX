package dev.cenzex.module;

import java.util.ArrayList;
import java.util.List;

public final class ModuleRegistry {
    private static final List<ClientModule> MODULES = new ArrayList<>();
    private ModuleRegistry() {}
    public static void initDefaults() {
        if (!MODULES.isEmpty()) return;
        MODULES.add(new ClientModule("HUD Editor", "Visual", "Toggle and configure the client HUD."));
        MODULES.add(new ClientModule("Coordinates", "Visual", "Show your current coordinates."));
        MODULES.add(new ClientModule("FPS Counter", "Visual", "Show frames per second."));
        MODULES.add(new ClientModule("Notifications", "Misc", "Show client-side status notifications."));
        MODULES.add(new ClientModule("Training Dummy", "Combat", "Local practice helper for a test world only."));
        MODULES.add(new ClientModule("Skin Preview", "Skins", "Preview cosmetic settings locally."));
    }
    public static List<ClientModule> all() { return List.copyOf(MODULES); }
    public static List<ClientModule> inCategory(String category) {
        return MODULES.stream().filter(m -> m.category().equals(category)).toList();
    }
}
