package dev.cenzex;

import dev.cenzex.config.ConfigManager;
import dev.cenzex.gui.CenzexScreen;
import dev.cenzex.module.ModuleRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class CenzexClient implements ClientModInitializer {
    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        ModuleRegistry.initDefaults();
        ConfigManager.load();
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cenzex.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new CenzexScreen());
            }
        });
        Runtime.getRuntime().addShutdownHook(new Thread(ConfigManager::save));
    }

    public static void notify(String message) {
        var client = net.minecraft.client.MinecraftClient.getInstance();
        if (client.player != null) client.player.sendMessage(Text.literal("§5[CENZEX] §f" + message), true);
    }
}
